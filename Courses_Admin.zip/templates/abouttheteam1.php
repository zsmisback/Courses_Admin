<?php include 'header_main.php'; ?>

      
	  


    

  <section id="team" class="pb-5 " style="background: url('images/body.jpg'); background-repeat: no-repeat; background-size: cover;">
    <div class="container">
        <h1 class="section-title text-center">OUR TEAM</h1>
        <div class="row">
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" >
                    <div class="mainflip flip-0">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/person_3.jpg" alt="card image"></p>
                                    <h4 class="card-title">CA Shashikant Khemani</h4>
                                    <p class="card-text">CFA</p>
                                <!--    <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                    <h4 class="card-title">CA Shashikant Khemani</h4>
                                    <p class="card-text">This is basic card with image on top, title, description and button.This is basic card with image on top, title, description and button.This is basic card with image on top, title, description and button.</p>
                                    <ul class="list-inline">
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-skype"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-google"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                    <div class="mainflip">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/munshiji.jpg" alt="card image"></p>
                                    <h4 class="card-title">Brij Mohan Sharma</h4>
                                    <p class="card-text">President</p>
                                  <!--  <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                    <h4 class="card-title">Brij Mohan Sharma</h4>
                                    <p class="card-text">He is a corporate leader, author, coach, visionary, a veteran Rashtrapati Scout, awarded in 1968 and devoted to the scouting spirit of Service.</p>
                                    <ul class="list-inline">
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-skype"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-google"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- ./Team member -->
            <!-- Team member -->
            <div class="col-xs-12 col-sm-6 col-md-4">
                <div class="image-flip" ontouchstart="this.classList.toggle('hover');">
                    <div class="mainflip">
                        <div class="frontside">
                            <div class="card">
                                <div class="card-body text-center">
                                    <p><img class=" img-fluid" src="images/person_2.jpg" alt="card image"></p>
                                    <h4 class="card-title">CA Vivek Agarwal</h4>
                                    <p class="card-text">CA</p>
                                 <!--   <a href="https://www.fiverr.com/share/qb8D02" class="btn btn-primary btn-sm"><i class="fa fa-plus"></i></a> -->
                                </div>
                            </div>
                        </div>
                        <div class="backside">
                            <div class="card">
                                <div class="card-body text-center mt-4">
                                    <h4 class="card-title">CA Vivek Agarwal</h4>
                                    <p class="card-text">He has more than 20 years of experience in providing consultancy in the areas of Finance, Accounting, Analytics, FP&A as well as designing financial and accounting systems for large corporates in India as well as Abroad.
</p>
                                    <ul class="list-inline">
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-facebook"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-twitter"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-skype"></i>
                                            </a>
                                        </li>
                                        <li class="list-inline-item">
                                            <a class="social-icon text-xs-center" target="_blank" href="https://www.fiverr.com/share/qb8D02">
                                                <i class="fa fa-google"></i>
                                            </a>
                                        </li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
			</div>
							<p>Besides this, we have the galaxy of educationists and corporate leaders who are devoted to the cause of youth empowerment through education and awareness in the field of Skill Development. </p>
			</div>

    </section>

	  
<!--	  	  <section class="site-section pt-3 element-animate" style="background: url('images/body.jpg'); background-repeat: no-repeat; background-size: cover;">
	   <div class="container">
	   <h2 class="text-primary text-center heading">Objectives</h2>
	   <p>We at BMS have a noble goal to make basic management skills and education easily available to common people.
Our key objectives are as follows:
</p>
   <ul>
   <li>To make the basic education and skills accessible to the youth of India, which in turn will help them get employment opportunities</li>
   <li>To empower our MSMEs with the basic financial and managerial expertise at affordable cost and to make them competitive at national and international levels.</li>
   </ul>
   <br><br>
   	   <div class="row">
	   <div class="col-md-6">
	   <h3 class="text-danger">Vision</h3>
	   <p>Empowering the youth to work and on their skills, upgrade themselves and make the world a better place to live in</p>
	   </div>
	   <div class="col-md-6">
	   <h3 class="text-danger">Motto</h3>
	   <p>To be a Pioneer and a Leader in providing Basic Management Education</p>
	   </div>
	   </div>
	   </div>

	   </section> -->
	    <section class="site-section pt-3 element-animate" style="background: url('images/body.jpg'); background-repeat: no-repeat; background-size: cover;">
	   <div class="container">
	   <div class="row">
	   <div class="col-md-6">
	   <h2 class="text-danger">Vision</h2>
	   <p>Empowering the youth to work and on their skills, upgrade themselves and make the world a better place to live in</p>
	   </div>
	   <div class="col-md-6">
	   <h2 class="text-danger">Mission</h2>
	   <p>To be a Pioneer and a Leader in providing Basic Management Education</p>
	   </div>
	   </div>
	   
	   <br><br>
	   <h2 class="text-danger text-center">Motto</h2>
	   <p class="text-center">Every youth can be a Basic Manager (BMBA) and every business can get affordable Managerial skills</p>
	  
	   
	   </div>

	   </section>
	  <section class="site-section pt-3 element-animate" style="background: url('images/body.jpg'); background-repeat: no-repeat; background-size: cover;">
	   <div class="container">
	   <h2 class="text-danger text-center heading">Idea behind Munshiji</h2>
	   <p class="text-left">The population of our country mainly comprises of youth and the future of our nation depends on how educated and skilled the youth is. The education field has been expanding over the years and so is the need for educated people. The whole idea behind starting with Munshiji is to contribute to the development of the nation by educating the youth and providing them the training of the required skills to start a business or get oneself employed.<br><br>At first, out of an initial enrolment of 100 students, on average, only 70 could manage to finish up with their studies. The rest of them couldn’t make through it because of a varied number of reasons. Munshiji aims at educating these students, helping them build a career and make themselves worthy enough to be employable or start a business themselves.<br><br>The development of their personalities in terms of the business knowledge and skills required and help make themselves employable is the core objective of Munshiji.</p>
	   </div>
	  </section>

<?php include 'footer_main.php'; ?>