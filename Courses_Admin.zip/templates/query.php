<?php include 'header_main.php'; ?>
    <!-- END header -->
      
      
    <section class="site-sectionn" style="background-image: url(images/query.jpg); background-repeat: no-repeat;
    background-attachment:scroll;
background-position: center center; background-size:cover;">

<div class="container">
<div class="row justify-content-center">
  <div class="col-md-8">
    <div class="form-wrap">
      <h2 class="mb-5">Any Query  &nbsp; <i class="fa fa-question" style="font-size:36px"></i></h2>
      <form action="#" method="post">
            <div class="row">
            <div class="col-md-12 form-group">
              <label for="name">In which lesson the query is?</label>
              <input type="text" id="name" class="form-control py-2">
            </div>
          </div>
   <div class="row">
            <div class="col-md-12 form-group">
              <label for="name">Details about the query?</label>
              <input type="text" id="name" class="form-control py-2">
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 form-group">
              <label for="name">Topic which you did not understood.</label>
              <input type="text" id="name" class="form-control py-2">
            </div>
          </div>
          <div class="row">
            <div class="col-md-12 form-group">
              <label for="name">Any suggestion?</label>
              <input type="text" id="name" class="form-control py-2 ">
            </div>
          </div>
          <div class="row mb-3">
            <div class="col-md-12 form-group">
              <label for="name">Any new lesson you want to learn?</label>
              <input type="text" id="name" class="form-control py-2">
            </div>
          </div>
  
          
          <div class="row">
            <div class="col-md-6 form-group">
              <input type="submit" value="Submit Query" class="btn btn-primary px-5 py-2">
            </div>
          </div>
        </form>
      </div>
  </div>
</div>
</div>
</section>

      
      
      
      <!-- Footer --->
<?php include 'footer_main.php'; ?>